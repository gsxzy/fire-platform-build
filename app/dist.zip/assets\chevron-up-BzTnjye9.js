import{i as o}from"./index-B0PfX5ik.js";const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",e);export{n as C};
