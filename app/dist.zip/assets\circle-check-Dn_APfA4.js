import{i as c}from"./index-B0PfX5ik.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],r=c("circle-check",e);export{r as C};
