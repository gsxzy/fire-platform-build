import{i as c}from"./index-B0PfX5ik.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]],r=c("circle-dot",e);export{r as C};
