import{c as e}from"./index-Cl3EwSnT.js";const t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],o=e("square",t);export{o as S};
